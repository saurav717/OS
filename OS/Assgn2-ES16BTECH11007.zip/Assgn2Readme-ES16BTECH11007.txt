Readme

a) for multi-processes program
  
                    to compile :-  g++ Assgn2-ProcStat-ES16BTECH11007.cpp -lrt -std=gnu++11 -lpthread
                    to execute :- ./a.out <filename.txt> 

b) for multi-Threaded program
       
                    to compile :-  g++ Assgn2-ThStat-ES16BTECH11007.cpp -lrt -std=gnu++11 -lpthread
                    to execute :- ./a.out <filename.txt> 

